package com.example.toytrader;

public class Toy {
}
